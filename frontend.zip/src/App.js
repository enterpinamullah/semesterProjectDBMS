import React, { useContext } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { AuthContext } from './contexts/AuthContext';
import Signin from './pages/Signin';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import Home from './pages/Home';
import VerifyOTP from './pages/VerifyOTP';
import MasterPatientConnect from './pages/MasterPatientConnect';

const App = () => {
  const {isLoggedIn} = useContext(AuthContext);
  return (
    <Router>
        <Routes>
          <Route path="/signin" element={<Signin />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/verifyOtp" element={<VerifyOTP />} />
          <Route path="/masterPatient" element={<MasterPatientConnect />} />
          {
            isLoggedIn ? (
                <Route path="/" element={<Dashboard />} />
            ) :(
              <Route path="/" element={<Home />} />
            )
          }
          
        </Routes>
    </Router>
  );
};

export default App;
