import React, { useContext } from 'react';
import { Card, CardContent, Typography, makeStyles } from '@material-ui/core';
import AllergyIcon from '@material-ui/icons/LocalFlorist';
import SeverityIcon from '@material-ui/icons/Warning';
import CalendarMonthTwoTone from '@material-ui/icons/CalendarViewDayTwoTone';
import ContactlessTwoTone from '@material-ui/icons/ContactlessTwoTone';
import { AuthContext } from '../contexts/AuthContext';
const useStyles = makeStyles((theme) => ({
  card: {
    marginBottom: theme.spacing(2),
    width: '100%',
  },
  content: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: theme.spacing(2),
  },
  cardTitle: {
    fontSize: '18px',
    fontWeight: 'bold',
    marginBottom: theme.spacing(2),
  },
  infoContainer: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: theme.spacing(2),
    paddingTop: theme.spacing(2),
    borderTop: '1px solid rgba(0, 0, 0, 0.2)',
  },
  infoItem: {
    display: 'flex',
    alignItems: 'center',
    marginBottom: theme.spacing(1),
    width: '49%',
  },
  icon: {
    marginRight: theme.spacing(1),
  },
  line: {
    height: '1px',
    background: 'rgba(0, 0, 0, 0.2)',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
    margin: `${theme.spacing(2)}px 0`,
  },
}));

const AllergyCard = () => {
  const classes = useStyles();
  const {allergyData} = useContext(AuthContext);
  return (
    <>
      {allergyData.map((data) => (
        <Card key={data.allergyIntoleranceId} className={classes.card}>
          <CardContent className={classes.content}>
            <Typography variant="h6" className={classes.cardTitle}>
              Allergy Information
            </Typography>
            <div className={classes.infoContainer}>
              <div className={classes.infoItem}>
                <AllergyIcon className={classes.icon} />
                <Typography variant="subtitle1">Allergy: {data.name}</Typography>
              </div>
              <div className={classes.infoItem}>
                <SeverityIcon className={classes.icon} />
                <Typography variant="subtitle1">Reaction: {data.reaction}</Typography>
              </div>
              <div className={classes.infoItem}>
                <CalendarMonthTwoTone className={classes.icon} />
                <Typography variant="subtitle1">Date: {data.date}</Typography>
              </div>
              <div className={classes.infoItem}>
                <ContactlessTwoTone className={classes.icon} />
                <Typography variant="subtitle1">Reaction Onset Date: {data.reactionOnsetDate}</Typography>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </>
  );
};

export default AllergyCard;
