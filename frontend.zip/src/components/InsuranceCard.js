import React, { useContext } from 'react';
import { Card, CardContent, Typography, makeStyles } from '@material-ui/core';
import { AuthContext } from '../contexts/AuthContext';

const useStyles = makeStyles((theme) => ({
  card: {
    marginBottom: theme.spacing(2),
    width: '100%',
  },
  content: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: theme.spacing(2),
  },
}));

const InsuranceCard = () => {
  const classes = useStyles();
  const { insuranceData } = useContext(AuthContext);

  return (
    <>
      {insuranceData && (
        <Card className={classes.card}>
          <CardContent className={classes.content}>
            <Typography variant="h6">Insurance Information</Typography>
            <Typography variant="subtitle1">Type: {insuranceData.type}</Typography>
            <Typography variant="subtitle1">Provider: {insuranceData.name}</Typography>
            <Typography variant="subtitle1">Status: {insuranceData.status}</Typography>
          </CardContent>
        </Card>
      )}
    </>
  );
};

export default InsuranceCard;
