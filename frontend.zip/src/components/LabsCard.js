import React, { useContext } from 'react';
import { Card, CardContent, Typography, makeStyles } from '@material-ui/core';
import ThirtyFpsSelectTwoTone from '@material-ui/icons/DateRange';
import EventIcon from '@material-ui/icons/Event';
import CreditCardIcon from '@material-ui/icons/CreditCard';
import LowPriorityTwoTone from '@material-ui/icons/LowPriorityTwoTone';
import { AuthContext } from '../contexts/AuthContext';

const useStyles = makeStyles((theme) => ({
  card: {
    marginBottom: theme.spacing(2),
    width: '100%',
  },
  content: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: theme.spacing(2),
  },
  cardTitle: {
    fontSize: '18px',
    fontWeight: 'bold',
    marginBottom: theme.spacing(2),
  },
  infoContainer: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: theme.spacing(2),
    paddingTop: theme.spacing(2),
    borderTop: '1px solid rgba(0, 0, 0, 0.2)',
  },
  infoItem: {
    display: 'flex',
    alignItems: 'center',
    marginBottom: theme.spacing(1),
    width: '49%',
  },
  icon: {
    marginRight: theme.spacing(1),
  },
  line: {
    height: '1px',
    background: 'rgba(0, 0, 0, 0.2)',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
    margin: `${theme.spacing(2)}px 0`,
  },
}));

const LabsCard = () => {
  const classes = useStyles();
  const {labsData} = useContext(AuthContext);
  return (
    <>
      {labsData.map((data, index) => (
        <Card key={data.observationLaboratoryId} className={classes.card}>
          {index === 0 && <div className={classes.line} />}
          <CardContent className={classes.content}>
            <Typography variant="h6" className={classes.cardTitle}>
              Laboratory Information
            </Typography>
            <div className={classes.infoContainer}>
              <div className={classes.infoItem}>
                <CreditCardIcon className={classes.icon} />
                <Typography variant="subtitle1">Type: {data.type}</Typography>
              </div>
              <div className={classes.infoItem}>
                <ThirtyFpsSelectTwoTone className={classes.icon} />
                <Typography variant="subtitle1">Value: {data.value + ' ' +data.unit}</Typography>
              </div>
              <div className={classes.infoItem}>
                <LowPriorityTwoTone className={classes.icon} />
                <Typography variant="subtitle1">Reference Range: {data.referenceRange}</Typography>
              </div>
              <div className={classes.infoItem}>
                <EventIcon className={classes.icon} />
                <Typography variant="subtitle1">Date: {data.date}</Typography>
              </div>
            </div>
          </CardContent>
          {(index === labsData.length - 1) && <div className={classes.line} />}
        </Card>
      ))}
    </>
  );
};

export default LabsCard;
