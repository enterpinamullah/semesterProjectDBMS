import React, { useContext } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { AuthContext } from '../contexts/AuthContext';

const VitalSignsChart = () => {
  const { vitalSignsData } = useContext(AuthContext);

  const filteredData = vitalSignsData.filter((dataPoint) =>
    ['Respiratory rate', 'Body Temperature', 'Heart Rate', 'Mean Blood Pressure', 'Oxygen Saturation in Arterial Blood'].includes(dataPoint.type)
  );

  const data = filteredData.map((dataPoint) => ({
    date: dataPoint.date,
    [dataPoint.type]: dataPoint.value,
    [`${dataPoint.type}_unit`]: dataPoint.unit,
  }));

  const lineColors = ['#8884d8', '#82ca9d', '#ffc658', '#FF7F50', '#0088FE'];
  const lineThickness = 2;
  
  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      const { date } = payload[0].payload;
      let tooltipContent = [];
  
      payload.forEach((entry) => {
        const { name, value } = entry;
        const unit = entry.payload[`${name}_unit`];
        const content = {
          type: name,
          value: `${value} ${unit ? unit : ''}`,
        };
        tooltipContent.push(content);
      });
  
      return (
        <div className="custom-tooltip">
          <p>{`Date: ${date}`}</p>
          {tooltipContent.map((content) => (
            <p key={content.type}>{`${content.type}: ${content.value}`}</p>
          ))}
        </div>
      );
    }
  
    return null;
  };
  

  return (
    <LineChart width={600} height={400} data={data}>
      <CartesianGrid stroke="#ccc" />
      <XAxis dataKey="date" />
      <YAxis />
      <Tooltip content={<CustomTooltip />} />
      <Legend />
      {['Respiratory rate', 'Body Temperature', 'Heart Rate', 'Mean Blood Pressure', 'Oxygen Saturation in Arterial Blood'].map((type, index) => (
        <Line
          key={type}
          type="monotone"
          dataKey={type}
          stroke={lineColors[index % lineColors.length]}
          strokeWidth={lineThickness}
          name={type}
        />
      ))}
    </LineChart>
  );
};

export default VitalSignsChart;
