import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { List, ListItem, ListItemIcon, ListItemText } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import {
  AllInclusive as AllergyIcon,
  Healing as ObservationIcon,
  Person as PatientIcon,
  LocalHospital as InsuranceIcon,
  LocalPharmacy as ImmunizationIcon,
  LocalOffer as ProceduresIcon,
  LocalHospital as ConditionIcon,
  RecentActors as EncounterIcon,
  LocalPharmacy as MedicationIcon,
  Description as CoverageIcon,
  Assignment as ClaimIcon,
} from '@material-ui/icons';
import { AuthContext } from '../contexts/AuthContext';
const useStyles = makeStyles((theme) => ({
    sidebar: {
      width: '250px',
      display: 'flex',
      flexDirection: 'column',
      backgroundColor: theme.palette.background.paper,
    },
  }));
  const Sidebar = () => {
    const {setNavItem} = useContext(AuthContext);


    const classes = useStyles();

    const onClickHandler = (e) => {
      setNavItem(e.target.innerText.toLowerCase())
    }
    return (
      <div className={classes.sidebar}>
        <List component="nav">
          <ListItem button component={Link} onClick={onClickHandler} >
            <ListItemIcon>
              <AllergyIcon style={{ fontSize: '2.5rem' }} />
            </ListItemIcon>
            <ListItemText primary="Allergy" />
          </ListItem>
          <ListItem button component={Link} onClick={onClickHandler}>
            <ListItemIcon>
              <ObservationIcon style={{ fontSize: '2.5rem' }} />
            </ListItemIcon>
            <ListItemText primary="Laboratory" />
          </ListItem>
          <ListItem button component={Link} onClick={onClickHandler} >
            <ListItemIcon>
              <ObservationIcon style={{ fontSize: '2.5rem' }} />
            </ListItemIcon>
            <ListItemText primary="Vital Signs" />
          </ListItem>
          <ListItem button component={Link} onClick={onClickHandler}>
            <ListItemIcon>
              <PatientIcon style={{ fontSize: '2.5rem' }} />
            </ListItemIcon>
            <ListItemText primary="Patient" />
          </ListItem>
          <ListItem button component={Link} onClick={onClickHandler}>
            <ListItemIcon>
              <InsuranceIcon style={{ fontSize: '2.5rem' }} />
            </ListItemIcon>
            <ListItemText primary="Insurance" />
          </ListItem>
          <ListItem button component={Link} onClick={onClickHandler}>
            <ListItemIcon>
              <ImmunizationIcon style={{ fontSize: '2.5rem' }} />
            </ListItemIcon>
            <ListItemText primary="Immunization" />
          </ListItem>
          <ListItem button component={Link} onClick={onClickHandler}>
            <ListItemIcon>
              <ProceduresIcon style={{ fontSize: '2.5rem' }} />
            </ListItemIcon>
            <ListItemText primary="Procedures" />
          </ListItem>
          <ListItem button component={Link} onClick={onClickHandler}>
            <ListItemIcon>
              <EncounterIcon style={{ fontSize: '2.5rem' }} />
            </ListItemIcon>
            <ListItemText primary="Encounter" />
          </ListItem>
          <ListItem button component={Link} onClick={onClickHandler}>
            <ListItemIcon>
              <ConditionIcon style={{ fontSize: '2.5rem' }} />
            </ListItemIcon>
            <ListItemText primary="Condition" />
          </ListItem>
          
          <ListItem button component={Link} onClick={onClickHandler}>
            <ListItemIcon>
              <MedicationIcon style={{ fontSize: '2.5rem' }} />
            </ListItemIcon>
            <ListItemText primary="Medication Request" />
          </ListItem>
          <ListItem button component={Link} onClick={onClickHandler}>
            <ListItemIcon>
              <CoverageIcon style={{ fontSize: '2.5rem' }} />
            </ListItemIcon>
            <ListItemText primary="Coverage" />
          </ListItem>
          <ListItem button component={Link} onClick={onClickHandler}>
            <ListItemIcon>
              <ClaimIcon style={{ fontSize: '2.5rem' }} />
            </ListItemIcon>
            <ListItemText primary="Claims" />
          </ListItem>
        </List>
      </div>
    );
  };
  
  export default Sidebar;
    