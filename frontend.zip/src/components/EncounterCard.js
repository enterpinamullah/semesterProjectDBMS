
import React, { useContext } from 'react';
import { Card, CardContent, Typography } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { EventNote, Description, Person,Class, HealingTwoTone } from '@material-ui/icons';
import { AuthContext } from '../contexts/AuthContext';

const useStyles = makeStyles({
    card: {
        width: '100%',
        marginBottom: '20px',
    },
    cardTitle: {
        fontSize: '18px',
        fontWeight: 'bold',
        marginBottom: '10px',
    },
    infoContainer: {
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'space-between',
    },
    infoItem: {
        display: 'flex',
        alignItems: 'center',
        marginBottom: '15px', // Adjust the margin to control the spacing
        width: '34%',
    },
    label: {
        fontWeight: 'bold',
        marginRight: '5px',
    },
    icon: {
        marginRight: '5px',
    },
    line: {
        height: '2px',
        background: 'rgba(0, 0, 0, 0.2)',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
        margin: '10px 0',
    },
});

const EncounterCard = () => {
    const classes = useStyles();
    const { encounterData } = useContext(AuthContext);
    return (
        <>
            {encounterData.map(encounter =>
                (
                    <Card key={encounter.encounterId} className={classes.card}>
                        <CardContent>
                            <Typography variant="h6" className={classes.cardTitle}>
                                Encounters Information
                            </Typography>

                            <div className={classes.line} />

                            <div className={classes.infoContainer}>
                                <div className={classes.infoItem}>
                                    <Person className={classes.icon} />
                                    <Typography variant="subtitle1" className={classes.label}>
                                        PractitionerId:
                                    </Typography>
                                    <Typography variant="subtitle1">{encounter.practitionerId}</Typography>
                                </div>
                                <div className={classes.infoItem}>
                                    <EventNote className={classes.icon} />
                                    <Typography variant="subtitle1" className={classes.label}>
                                        Date:
                                    </Typography>
                                    <Typography variant="subtitle1">{encounter.date}</Typography>
                                </div>
                                <div className={classes.infoItem}>
                                    <HealingTwoTone className={classes.icon} />
                                    <Typography variant="subtitle1" className={classes.label}>
                                        Diagnosis:
                                    </Typography>
                                    <Typography variant="subtitle1">{encounter.diagnosis}</Typography>
                                </div>
                                <div className={classes.infoItem}>
                                    <Class className={classes.icon} />
                                    <Typography variant="subtitle1" className={classes.label}>
                                        Class:
                                    </Typography>
                                    <Typography variant="subtitle1">{encounter.class}</Typography>
                                </div>
                                <div className={classes.infoItem}>
                                    <Description className={classes.icon} />
                                    <Typography variant="subtitle1" className={classes.label}>
                                        Type:
                                    </Typography>
                                    <Typography variant="subtitle1">{encounter.type}</Typography>
                                </div>
                            </div>

                            <div className={classes.line} />
                        </CardContent>
                    </Card>
                )
            )}

        </>

    );
};

export default EncounterCard;
