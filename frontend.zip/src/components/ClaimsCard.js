
import React, { useContext } from 'react';
import { Card, CardContent, Typography } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { EventNote, Description, Person,Class, HealingTwoTone } from '@material-ui/icons';
import { AuthContext } from '../contexts/AuthContext';

const useStyles = makeStyles({
    card: {
        width: '100%',
        marginBottom: '20px',
    },
    cardTitle: {
        fontSize: '18px',
        fontWeight: 'bold',
        marginBottom: '10px',
    },
    infoContainer: {
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'space-between',
    },
    infoItem: {
        display: 'flex',
        alignItems: 'center',
        marginBottom: '15px', // Adjust the margin to control the spacing
        width: '34%',
    },
    label: {
        fontWeight: 'bold',
        marginRight: '5px',
    },
    icon: {
        marginRight: '5px',
    },
    line: {
        height: '2px',
        background: 'rgba(0, 0, 0, 0.2)',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
        margin: '10px 0',
    },
});

const ClaimsCard = () => {
    const classes = useStyles();
    const { claimData } = useContext(AuthContext);
    return (
        <>
            {claimData.map(claim =>
                (
                    <Card key={claim.claimId} className={classes.card}>
                        <CardContent>
                            <Typography variant="h6" className={classes.cardTitle}>
                                Claims Information
                            </Typography>

                            <div className={classes.line} />

                            <div className={classes.infoContainer}>
                                <div className={classes.infoItem}>
                                    <Person className={classes.icon} />
                                    <Typography variant="subtitle1" className={classes.label}>
                                        MedicationRequestId:
                                    </Typography>
                                    <Typography variant="subtitle1">{claim.medicationRequestId}</Typography>
                                </div>
                                <div className={classes.infoItem}>
                                    <EventNote className={classes.icon} />
                                    <Typography variant="subtitle1" className={classes.label}>
                                        Date:
                                    </Typography>
                                    <Typography variant="subtitle1">{claim.claimDate}</Typography>
                                </div>
                                <div className={classes.infoItem}>
                                    <HealingTwoTone className={classes.icon} />
                                    <Typography variant="subtitle1" className={classes.label}>
                                        Total Cost:
                                    </Typography>
                                    <Typography variant="subtitle1">{claim.claimAmount}</Typography>
                                </div>
                                <div className={classes.infoItem}>
                                    <Class className={classes.icon} />
                                    <Typography variant="subtitle1" className={classes.label}>
                                        Status:
                                    </Typography>
                                    <Typography variant="subtitle1">{claim.description}</Typography>
                                </div>
                                <div className={classes.infoItem}>
                                    <Description className={classes.icon} />
                                    <Typography variant="subtitle1" className={classes.label}>
                                        Active:
                                    </Typography>
                                    <Typography variant="subtitle1">{claim.status}</Typography>
                                </div>
                            </div>

                            <div className={classes.line} />
                        </CardContent>
                    </Card>
                )
            )}

        </>

    );
};

export default ClaimsCard;
