import React, { useContext } from 'react';
import { Card, CardContent, Typography } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import PersonIcon from '@material-ui/icons/Person';
import EventIcon from '@material-ui/icons/Event';
import CreditCardIcon from '@material-ui/icons/CreditCard';
import PhoneIcon from '@material-ui/icons/Phone';
import EmailIcon from '@material-ui/icons/Email';
import LocationOnIcon from '@material-ui/icons/LocationOn';
import AccountBalanceIcon from '@material-ui/icons/AccountBalance';
import { AuthContext } from '../contexts/AuthContext';

const useStyles = makeStyles({
  card: {
    width: '100%',
    marginBottom: '20px',
  },
  cardTitle: {
    fontSize: '18px',
    fontWeight: 'bold',
    marginBottom: '10px',
  },
  infoContainer: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  infoItem: {
    display: 'flex',
    alignItems: 'center',
    marginBottom: '15px', // Adjust the margin to control the spacing
    width: '34%',
  },
  label: {
    fontWeight: 'bold',
    marginRight: '5px',
  },
  icon: {
    marginRight: '5px',
  },
  line: {
    height: '2px',
    background: 'rgba(0, 0, 0, 0.2)',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
    margin: '10px 0',
  },
});

const PatientCard = () => {
  const classes = useStyles();
  const {patientData} = useContext(AuthContext);
  return (
    <Card className={classes.card}>
      <CardContent>
        <Typography variant="h6" className={classes.cardTitle}>
          Patient Information
        </Typography>

        <div className={classes.line} />

        <div className={classes.infoContainer}>
          <div className={classes.infoItem}>
            <PersonIcon className={classes.icon} />
            <Typography variant="subtitle1" className={classes.label}>
              Name:
            </Typography>
            <Typography variant="subtitle1">{patientData.name}</Typography>
          </div>
          <div className={classes.infoItem}>
            <EventIcon className={classes.icon} />
            <Typography variant="subtitle1" className={classes.label}>
              Date of Birth:
            </Typography>
            <Typography variant="subtitle1">{patientData.dob}</Typography>
          </div>
          <div className={classes.infoItem}>
            <CreditCardIcon className={classes.icon} />
            <Typography variant="subtitle1" className={classes.label}>
              CNIC:
            </Typography>
            <Typography variant="subtitle1">{patientData.cnic}</Typography>
          </div>
          <div className={classes.infoItem}>
            <PhoneIcon className={classes.icon} />
            <Typography variant="subtitle1" className={classes.label}>
              Telephone:
            </Typography>
            <Typography variant="subtitle1">{patientData.telephone}</Typography>
          </div>
          <div className={classes.infoItem}>
            <EmailIcon className={classes.icon} />
            <Typography variant="subtitle1" className={classes.label}>
              Email:
            </Typography>
            <Typography variant="subtitle1">{patientData.email}</Typography>
          </div>
          <div className={classes.infoItem}>
            <LocationOnIcon className={classes.icon} />
            <Typography variant="subtitle1" className={classes.label}>
              Address:
            </Typography>
            <Typography variant="subtitle1">{patientData.address}</Typography>
          </div>
          <div className={classes.infoItem}>
            <AccountBalanceIcon className={classes.icon} />
            <Typography variant="subtitle1" className={classes.label}>
              Insurance ID:
            </Typography>
            <Typography variant="subtitle1">{patientData.insuranceId}</Typography>
          </div>
        </div>

        <div className={classes.line} />
      </CardContent>
    </Card>
  );
};

export default PatientCard;
