
import React, { useContext } from 'react';
import { Card, CardContent, Typography } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { Description,Class, HealingTwoTone } from '@material-ui/icons';
import { AuthContext } from '../contexts/AuthContext';

const useStyles = makeStyles({
    card: {
        width: '100%',
        marginBottom: '20px',
    },
    cardTitle: {
        fontSize: '18px',
        fontWeight: 'bold',
        marginBottom: '10px',
    },
    infoContainer: {
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'space-between',
    },
    infoItem: {
        display: 'flex',
        alignItems: 'center',
        marginBottom: '15px', // Adjust the margin to control the spacing
        width: '34%',
    },
    label: {
        fontWeight: 'bold',
        marginRight: '5px',
    },
    icon: {
        marginRight: '5px',
    },
    line: {
        height: '2px',
        background: 'rgba(0, 0, 0, 0.2)',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
        margin: '10px 0',
    },
});

const MedicationRequestCard = () => {
    const classes = useStyles();
    const { medicationRequestData } = useContext(AuthContext);
    return (
        <>
            {medicationRequestData.map(medicationRequest =>
                (
                    <Card key={medicationRequest.medicationRequestId} className={classes.card}>
                        <CardContent>
                            <Typography variant="h6" className={classes.cardTitle}>
                                Medication Request Info
                            </Typography>

                            <div className={classes.line} />

                            <div className={classes.infoContainer}>
                                <div className={classes.infoItem}>
                                    <HealingTwoTone className={classes.icon} />
                                    <Typography variant="subtitle1" className={classes.label}>
                                        MedicationCode:
                                    </Typography>
                                    <Typography variant="subtitle1">{medicationRequest.medicationCode}</Typography>
                                </div>
                                <div className={classes.infoItem}>
                                    <Class className={classes.icon} />
                                    <Typography variant="subtitle1" className={classes.label}>
                                        Performer:
                                    </Typography>
                                    <Typography variant="subtitle1">{medicationRequest.performer}</Typography>
                                </div>
                                <div className={classes.infoItem}>
                                    <Description className={classes.icon} />
                                    <Typography variant="subtitle1" className={classes.label}>
                                        Quantity:
                                    </Typography>
                                    <Typography variant="subtitle1">{medicationRequest.quantity}</Typography>
                                </div>
                                <div className={classes.infoItem}>
                                    <Description className={classes.icon} />
                                    <Typography variant="subtitle1" className={classes.label}>
                                        Days Supply:
                                    </Typography>
                                    <Typography variant="subtitle1">{medicationRequest.dayssupply}</Typography>
                                </div>
                                <div className={classes.infoItem}>
                                    <Description className={classes.icon} />
                                    <Typography variant="subtitle1" className={classes.label}>
                                        When Prepared:
                                    </Typography>
                                    <Typography variant="subtitle1">{medicationRequest.whenPrepared}</Typography>
                                </div>
                                <div className={classes.infoItem}>
                                    <Description className={classes.icon} />
                                    <Typography variant="subtitle1" className={classes.label}>
                                        Status:
                                    </Typography>
                                    <Typography variant="subtitle1">{medicationRequest.status}</Typography>
                                </div>
                            </div>

                            <div className={classes.line} />
                        </CardContent>
                    </Card>
                )
            )}

        </>

    );
};
export default MedicationRequestCard;
