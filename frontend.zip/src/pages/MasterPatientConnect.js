import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../config/axiosConfig';
import {
  Paper,
  Typography,
  TextField,
  Button,
  makeStyles,
} from '@material-ui/core';
import Loader from './../components/Loader'
const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
  },
  paper: {
    padding: theme.spacing(2),
    width: 300,
  },
  title: {
    marginBottom: theme.spacing(2),
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: theme.spacing(2),
  },
}));

const MasterPatientConnect = () => {
  const [email, setEmail] = useState('');
  const [patientId, setPatientId] = useState('');
  const navigate = useNavigate();
  const classes = useStyles();
  const [isLoading, setIsLoading] = useState(false);

  const handleConnect = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const response = await axios.post('/auth/v1/connectpatient', {
        email,
        patientId: parseInt(patientId),
      });

      if (response.status === 200) {
        // Connection successful, redirect to dashboard
        setIsLoading(false);
        navigate('/signin');
      } else {
        // Handle the error, e.g., display an error message to the user
        setIsLoading(false);
        console.error('Connection failed');
      }
    } catch (error) {
      // Handle network errors or other exceptions
      setIsLoading(false);
      console.error(error);
    }
  };

  return (
    <div className={classes.root}>
    {isLoading && <Loader />}
      <Paper className={classes.paper} elevation={3}>
        <Typography variant="h5" className={classes.title}>
          Connect Patient
        </Typography>
        <form onSubmit={handleConnect} className={classes.form}>
            <TextField
            type="email"
            label="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <TextField
            type="text"
            label="Patient ID"
            value={patientId}
            onChange={(e) => setPatientId(e.target.value)}
            required
          />
          <Button type="submit" variant="contained" color="primary">
            Connect
          </Button>
        </form>
      </Paper>
    </div>
  );
};

export default MasterPatientConnect;
