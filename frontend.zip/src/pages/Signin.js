import React, { useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Paper,
  Typography,
  TextField,
  Button,
  makeStyles,
} from '@material-ui/core';
import Loader from '../components/Loader';
import { AuthContext } from '../contexts/AuthContext';

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
  },
  paper: {
    padding: theme.spacing(2),
    width: 300,
  },
  title: {
    marginBottom: theme.spacing(2),
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: theme.spacing(2),
  },
}));

const Signin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  const classes = useStyles();
  const { login,isLoggedIn } = useContext(AuthContext);
  const [isLoading, setIsLoading] = useState(false); 

  useEffect(() => {
    if (isLoggedIn) {
      setIsLoading(false);
      navigate('/');
    }
  }, [isLoggedIn, navigate]);
  const handleSignin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    // Call the login function from the AuthContext to handle the login process
    login(email, password);

    // setTimeout(() => {
    //     if(!isLoggedIn){
    //         setIsLoading(false);
    //     }
    // }, 1000);
  };

  return (
    <div className={classes.root}>
      {isLoading && <Loader />}
      <Paper className={classes.paper} elevation={3}>
        <Typography variant="h5" className={classes.title}>
          Sign In
        </Typography>
        <form onSubmit={handleSignin} className={classes.form}>
          <TextField
            type="email"
            label="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <TextField
            type="password"
            label="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <Button type="submit" variant="contained" color="primary">
            Sign In
          </Button>
        </form>
      </Paper>
    </div>
  );
};

export default Signin;
