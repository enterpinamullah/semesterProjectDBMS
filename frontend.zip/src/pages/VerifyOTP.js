import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../config/axiosConfig';
import {
  Paper,
  Typography,
  TextField,
  Button,
  makeStyles,
} from '@material-ui/core';
import Loader from './../components/Loader';

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
  },
  paper: {
    padding: theme.spacing(2),
    width: 300,
  },
  title: {
    marginBottom: theme.spacing(2),
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: theme.spacing(2),
  },
}));

const VerifyOTP = () => {
  const [verificationCode, SetVerificationCode] = useState(null);
  const [email, setEmail] = useState('');
  const navigate = useNavigate();
  const classes = useStyles();
  const [isLoading, setIsLoading] = useState(false);

  const handleVerifyVericationCode = async (e) => {
    e.preventDefault();

    try {
      setIsLoading(true);
      const response = await axios.post('/auth/v1/verifyRegistration', 
      { email,
        verificationCode: parseInt(verificationCode),
      });

      if (response.status === 200) {
        // OTP verification successful, redirect to a new page
        navigate('/masterPatient');
      } else {
        // Handle the error, e.g., display an error message to the user
        console.error('OTP verification failed');
      }
    } catch (error) {
      // Handle network errors or other exceptions
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={classes.root}>
      {isLoading && <Loader />}
      <Paper className={classes.paper} elevation={3}>
        <Typography variant="h5" className={classes.title}>
          Verify OTP
        </Typography>
        <form onSubmit={handleVerifyVericationCode} className={classes.form}>
            <TextField
            type="email"
            label="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <TextField
            type="text"
            label="OTP"
            value={verificationCode}
            onChange={(e) => SetVerificationCode(e.target.value)}
            required
          />
          <Button type="submit" variant="contained" color="primary">
            Verify
          </Button>
        </form>
      </Paper>
    </div>
  );
};

export default VerifyOTP;
