import React from 'react';
import { Link } from 'react-router-dom';
import { Typography, Button, Container } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
const useStyles = makeStyles((theme) => ({
  container: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  button: {
    marginTop: theme.spacing(2),
  },
}));
const Home = () => {
  const classes = useStyles();

  return (
    <Container maxWidth="sm" className={classes.container}>
      <Typography variant="h4" component="h1" align="center">
        Welcome to the Home Page
      </Typography>
      <Button
        variant="contained"
        color="primary"
        component={Link}
        to="/signup"
        className={classes.button}
      >
        Sign Up
      </Button>
      <Button
        variant="contained"
        color="primary"
        component={Link}
        to="/signin"
        className={classes.button}
      >
        Sign In
      </Button>
    </Container>
  );
};

export default Home;
