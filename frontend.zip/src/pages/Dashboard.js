import React, { useContext, useEffect, useState  } from 'react';
import { AuthContext } from '../contexts/AuthContext';
import { Link } from 'react-router-dom';
import { Typography, Container, Grid, AppBar, Toolbar, IconButton } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import axios from './../config/axiosConfig';
import Sidebar from '../components/Sidebar';
import { DomainTwoTone, HomeTwoTone, ExitToAppTwoTone, SyncTwoTone } from '@material-ui/icons';
import AllergyCard from '../components/AllergyCard';
import LabsCard from '../components/LabsCard';
import Loader from '../components/Loader';
import VitalSignsCard from '../components/VitalSignsCard';
import PatientCard from '../components/PatientCard';
import InsuranceCard from '../components/InsuranceCard';
import ProcedureCard from '../components/ProceduresCard';
import ConditionCard from '../components/ConditionCard';
import EncounterCard from '../components/EncounterCard';
import MedicationRequestCard from '../components/MedicationRequestCard';
import CoverageCard from '../components/CoverageCard';
import ClaimsCard from '../components/ClaimsCard';
import ImmunizationCard from '../components/ImmunizationsCard';
const useStyles = makeStyles((theme) => ({
  appBar: {
    position: "fixed",
    left: 0,
    right: 0,
    backgroundColor: theme.palette.common.white,
    color: theme.palette.primary.main,
    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)", // Add sleek shadow
  },
  container: {
    marginTop: theme.spacing(10),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  gridContainer: {
    marginTop: theme.spacing(1),
  },
  logoContainer: {
    display: 'flex',
    alignItems: 'center',
    flexGrow: 1,
  },
  logo: {
    marginRight: theme.spacing(2),
    fontSize: '4rem', // Increase logo size
  },
  sidebarContainer: {
    height: 'calc(100vh - 0px)',
    position: 'fixed',
    left: 0,
    top: 80,
    bottom: 0,
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between',
    zIndex: theme.zIndex.drawer + 1,
    paddingRight: theme.spacing(3),
  },
  contentContainer: {
    marginLeft: theme.spacing(18),
  },
}));

const Dashboard = () => {
  const classes = useStyles();
  const { user,
    authToken,
    allergyData,
    navItem,
    labsData, 
    vitalSignsData, 
    patientData,
    proceduresData,
    insuranceData,
    immunizationData,
    conditionData,
    encounterData,
    medicationRequestData,
    coverageData,
    claimData,
    setConditionData,
    setEncounterData,
    setMedicationRequestData,
    setCoverageData,
    setClaimData,
    setImmunizationData,
    setInsuranceData,
    setProceduresData,
    setPatientData,
    setVitalSignsData,
    setLabsData,
    setAllergyData,
    logout } = useContext(AuthContext);
  const [isLoading, setIsLoading ] = useState(false);
  const fetchAllResources = async () => {
    setIsLoading(true);
    try {
      const response = await axios.get(`/api/v1/patient/${user.patientId}/resources`, {
        headers: {
          "x-token": authToken,
        },
      });
      setAllergyData(response.data.AllergyIntolerances);
      setLabsData(response.data.ObservationLaboratories);
      setVitalSignsData(response.data.ObservationVitalSigns);
      setPatientData(response.data);

      const insurance = await axios.get(`/api/v1/insurance/${response.data.insuranceId}`, {
        headers: {
          "x-token": authToken,
        },
      });
      setInsuranceData(insurance.data)
      setProceduresData(response.data.Procedures)
      setConditionData(response.data.Conditions)
      setEncounterData(response.data.Encounters)
      setMedicationRequestData(response.data.MedicationRequests)
      setCoverageData(response.data.Coverage)
      setImmunizationData(response.data.Immunizations)
      const claims = await axios.get(`/api/v1/claims/coverage/${response.data.Coverage.coverageId}`, {
        headers: {
          "x-token": authToken,
        },
      });
      setClaimData(claims.data);
      setIsLoading(false);
    } catch (error) {
      setIsLoading(false);
      console.error('Error fetching patient data:', error);
    }
  };
  useEffect(() => {
    setIsLoading(true);
    fetchAllResources();
  },[]);
  
  return (
    <Container maxWidth="lg">
      {isLoading && <Loader />}
      <AppBar position="static" className={classes.appBar}>
        <Toolbar>
          <div className={classes.logoContainer}>
            <DomainTwoTone className={classes.logo} />
            <Typography variant="h6" component="h1">
              UET Patient Data Access Portal
            </Typography>
          </div>
          <div>
            <IconButton color="inherit" aria-label="home" component={Link} onClick={async()=>{await fetchAllResources()}}>
              <SyncTwoTone style={{ fontSize: '2.5rem' }} />
            </IconButton>
            <IconButton color="inherit" aria-label="home" component={Link} to="/">
              <HomeTwoTone style={{ fontSize: '2.5rem' }}/>
            </IconButton>
            <IconButton color="inherit" aria-label="home" component={Link} onClick={async()=>{await logout()}}>
              <ExitToAppTwoTone style={{ fontSize: '2.5rem' }} />
            </IconButton>
          </div>
        </Toolbar>
      </AppBar>
      <div className={classes.sidebarContainer}>
        <Sidebar navItem={navItem} />
      </div>
      <div className={classes.contentContainer}>
        <Grid container className={classes.gridContainer}>
          <Grid item xs={12}>
            <Container maxWidth="md" className={classes.container}>
              <Typography variant="h4" component="h1" align="center">
                Welcome {user && (user.firstName + ' ' + user.lastName)}
              </Typography>
              {/* Content */}
              {allergyData && (navItem === "allergy") && <AllergyCard  />}
              {labsData && (navItem === "laboratory") && <LabsCard />}
              {vitalSignsData && (navItem === "vital signs") && <VitalSignsCard />}
              {patientData && (navItem === "patient") && <PatientCard />}
              {insuranceData && (navItem === "insurance") && <InsuranceCard />}
              {proceduresData && (navItem === "procedures") && <ProcedureCard />}
              {conditionData && (navItem === "condition") && <ConditionCard />}
              {encounterData && (navItem === "encounter") && <EncounterCard />}
              {medicationRequestData && (navItem === "medication request") && <MedicationRequestCard />}
              {coverageData && (navItem === "coverage") &&  <CoverageCard />}
              {claimData && (navItem === "claims") &&  <ClaimsCard />}
              {immunizationData && (navItem === "immunization") &&  <ImmunizationCard />}
            </Container>
          </Grid>
        </Grid>
      </div>
    </Container>
  );
};

export default Dashboard;
