import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../config/axiosConfig';
import Loader from './../components/Loader'
import {
  Paper,
  Typography,
  TextField,
  Button,
  makeStyles,
} from '@material-ui/core';

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
  },
  paper: {
    padding: theme.spacing(2),
    width: 300,
  },
  title: {
    marginBottom: theme.spacing(2),
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: theme.spacing(2),
  },
}));

const Signup = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const navigate = useNavigate();
  const classes = useStyles();
  const [isLoading, setIsLoading] = useState(false);

  const handleSignup = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const response = await axios.post('/auth/v1/register', {
        firstName,
        lastName,
        email,
        password,
      });

      if (response.status === 200) {
        // Signup successful, redirect the user to a new page masterPatientConnect
        setIsLoading(false);
        navigate('/verifyOtp');
      } else {
        // Handle the error, e.g., display an error message to the user
        setIsLoading(false);
        console.error('Signup failed');
      }
    } catch (error) {
      setIsLoading(false);
      // Handle network errors or other exceptions
      console.error(error);
    }
  };

  return (
    <div className={classes.root}>
      {isLoading && <Loader />}
      <Paper className={classes.paper} elevation={3}>
        <Typography variant="h5" className={classes.title}>
          Sign Up
        </Typography>
        <form onSubmit={handleSignup} className={classes.form}>
          <TextField
            type="text"
            label="First Name"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            required
          />
          <TextField
            type="text"
            label="Last Name"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            required
          />
          <TextField
            type="email"
            label="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <TextField
            type="password"
            label="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <Button type="submit" variant="contained" color="primary">
            Sign Up
          </Button>
        </form>
      </Paper>
    </div>
  );
};

export default Signup;
