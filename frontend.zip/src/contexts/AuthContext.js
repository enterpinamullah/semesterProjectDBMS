import React, { createContext, useEffect, useState } from 'react';
import axios from './../config/axiosConfig'

const AuthContext = createContext();

const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [authToken, setAuthToken] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [allergyData, setAllergyData] = useState(null);
  const [labsData, setLabsData] = useState(null);
  const [vitalSignsData, setVitalSignsData] = useState(null);
  const [patientData, setPatientData] = useState(null);
  const [proceduresData, setProceduresData] = useState(null);
  const [navItem, setNavItem] = useState('patient');
  const [insuranceData,setInsuranceData] = useState(null);
  const [immunizationData,setImmunizationData] = useState(null);
  const [conditionData, setConditionData] = useState(null);
  const [encounterData, setEncounterData] = useState(null);
  const [medicationRequestData, setMedicationRequestData] = useState(null);
  const [coverageData, setCoverageData] = useState(null);
  const [claimData,setClaimData] = useState(null);
  
  useEffect(()=>{
    const storedUser = JSON.parse(localStorage.getItem('user'));
    const storedToken = JSON.parse(localStorage.getItem('token'));

    if(!storedUser && !storedToken){
        setIsLoggedIn(false);
    }else{
        setUser(storedUser);
        setAuthToken(storedToken);
        setIsLoggedIn(true);
    }
  }, [])
  const login = async (email, password) => {
    // Call your login API with the provided email and password
    try{
        const response = await axios.post('/auth/v1/login', { email, password });

        // Assuming the login was successful, set the user and navigate to the dashboard
        const user = response.data.data.user;
        const token = response.data.data.token;
        setUser(user);
        setAuthToken(token);

        setIsLoggedIn(true);
        localStorage.setItem('user', JSON.stringify(user));
        localStorage.setItem('token', JSON.stringify(token));
    }catch(err){
        setIsLoggedIn(false);
    }
    
  };

  const logout = () => {
    // Clear the user information
    setUser(null);
    setAuthToken(null);
    setIsLoggedIn(false); // Set isAuthenticated to false
    // Perform any other necessary cleanup
    // For example, you can clear any authentication tokens stored in localStorage
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    // Redirect the user to the login page or any other desired route
  };


  return (
    <AuthContext.Provider value={{ isLoggedIn,
    user,
    authToken,
    allergyData,
    navItem,
    labsData, 
    vitalSignsData, 
    patientData,
    proceduresData,
    insuranceData,
    immunizationData,
    conditionData,
    encounterData,
    medicationRequestData,
    coverageData,
    claimData,
    setConditionData,
    setEncounterData,
    setMedicationRequestData,
    setCoverageData,
    setClaimData,
    setImmunizationData,
    setInsuranceData,
    setProceduresData,
    setPatientData,
    setVitalSignsData,
    setLabsData,
    setAllergyData,
    setNavItem,
    login,
    logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export { AuthContext, AuthProvider };

